// ==UserScript==
// @name         Enable Interactions and Remove Class Attributes V1
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Enable right click, keyboard shortcuts, and text selection for all websites, and remove class attributes from elements on the initial domain
// @author       You
// @match        *://*/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

// Function to remove the class attribute (only for the initial domain)
function removeClassAttribute() {
    if (window.location.hostname === 'daotranslate.com') {
        // Get the <body> element
        var bodyElement = document.body;

        // Remove the class attribute
        bodyElement.removeAttribute('class');

        // Print a message to indicate that the class attribute has been removed
        console.log('Class attribute removed:', bodyElement.getAttribute('class'));
    }
}

// Function to run the removal at intervals
function runRemovalAtIntervals() {
    // Initial removal
    removeClassAttribute();
}

// Function to enable right click, keyboard shortcuts, and text selection for all websites
function enableInteractions() {
    document.oncontextmenu = document.body.oncontextmenu = function() { return true; };
    document.onkeydown = document.body.onkeydown = function() { return true; };
    document.onmousedown = document.body.onmousedown = function() { return true; };
    document.onselectstart = document.body.onselectstart = function() { return true; };

    // Additional event handlers for text selection
    document.onmouseup = document.body.onmouseup = function() { return true; };
    document.onmousemove = document.body.onmousemove = function() { return true; };
    document.oncopy = document.body.oncopy = function() { return true; };

     // Allowing click event to select text
    document.onclick = document.body.onclick = function() { return true; };

    // Allowing click and drag for text selection
    document.ondragstart = document.body.ondragstart = function() { return true; };


}

// Use the window.onload event to ensure the DOM is fully loaded
window.onload = function() {
    // Initial calls to remove class attributes and enable interactions
    runRemovalAtIntervals();
    enableInteractions();

    console.log('Script started');

    // Set an interval to run the removal function and enable interactions every 1.5 seconds (1500 milliseconds)
    setInterval(function() {
        runRemovalAtIntervals();
        enableInteractions();
    }, 1500);
};
