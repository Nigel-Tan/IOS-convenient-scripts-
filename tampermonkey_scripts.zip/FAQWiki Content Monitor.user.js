// ==UserScript==
// @name         FAQWiki Content Monitor
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Monitor and restore changes to the 'page' div content on FAQWiki
// @author       You
// @match        https://faqwiki.us/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Get the original HTML content of the 'page' div
    const originalContent = document.getElementById('page').innerHTML;

    // Monitor changes to the 'page' div using a MutationObserver
    const observer = new MutationObserver(() => {
        // If content changes, restore the original HTML
        const currentPage = document.getElementById('page');
        if (currentPage.innerHTML !== originalContent) {
            currentPage.innerHTML = originalContent;
        }
    });

    // Specify the target node and options for the observer
    const targetNode = document.getElementById('page');
    const config = { childList: true, subtree: true };

    // Start observing the target node for changes
    observer.observe(targetNode, config);
})();
