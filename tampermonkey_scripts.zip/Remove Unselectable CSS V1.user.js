// ==UserScript==
// @name         Remove Unselectable CSS V1
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Remove the effects of unselectable CSS
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Remove or override the unselectable styles
    var styleTag = document.createElement('style');
    styleTag.textContent = '.unselectable { -moz-user-select: initial !important; -webkit-user-select: initial !important; cursor: initial !important; }' +
                          'html { -webkit-touch-callout: initial !important; -webkit-user-select: initial !important; -khtml-user-select: initial !important; -moz-user-select: initial !important; -ms-user-select: initial !important; user-select: initial !important; -webkit-tap-highlight-color: initial !important; }';
    document.head.appendChild(styleTag);
})();
